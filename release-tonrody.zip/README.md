﻿# tonvrodyy1

## Автоматическая очистка инвайтов
Каждые 10 минут backend вызывает deleteExpiredInvites() для удаления просроченных записей из Supabase (если Supabase доступен).

